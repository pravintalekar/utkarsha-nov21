
public class array {
// 0 - n-1  5 elements == 0,1,2,3,4
//array == fixed size of elements 
//similar types are used
	//2 types - syntax- datatypes var[] or datatypes[] var
//length int value return
	public static void main(String a[]) {
	// 1st type	int a1[] = {24,25,26,27,28}; // 24=0,25=1, 26=2, 27=3,28=4;
		//int b[];
	
	//System.out.println(a1[0]); //print 1 element of array
	/*for(int i=0; i<=4; i++)    
	{
		System.out.println(a1[i]);  // print all elements of array  using for loop
	}*/
	//int l=a1.length; // calcualte array size by lenght return int value
	//System.out.println("array length="+l);
	
	
	/*for(int j=0;j<=a1.length-1; j++)  // if j<= then a1.length-1  
	{							// j< then a1.lenght;
		System.out.println(a1[j]);
	}
		*/
	
	/*for(int k=a1.length-1; k>=0; k--)  // reverse array
	{
		System.out.println(a1[k]);
	}*/
	
	// 2nd type  
	// data var[] = new data[5];
	
	int a1[]=new int[5];
	a1[0]=21;
	a1[1]=22;
	a1[2]=23;
	a1[3]=24;
	a1[4]=25;
	
	System.out.println("Forward Arrya Print");
	
	for(int m=0; m<=a1.length-1; m++)
	{
		System.out.println(a1[m]);
	}
	
	System.out.println("Backward Arrya Print");
	
	for(int n=a1.length-1; n>=0; n--)
	{
		System.out.println(a1[n]);
	}
	
	}

}
