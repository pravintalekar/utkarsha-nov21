
public class TwoDarray {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int a[][] = {{2,3},
					{4,5} };
		int b[][] = new int[3][3];
		b[0][0]= 10;
		b[0][1]= 20; // 10  20  19
		b[0][2]= 19; // 18  17  16
		b[1][0]= 18;//  15  14  13
		b[1][1]= 17;
		b[1][2]= 16;
		b[2][0]= 15;
		b[2][1]= 14;
		b[2][2]= 13;
		
		for(int i=0; i<2; i++)
		{
			for(int j=0; j<2; j++) {
			System.out.print(a[i][j] + "   ");
			}System.out.println();
		}
		
		for(int i=0; i<3; i++)
		{
			for(int j=0; j<3; j++) {
				System.out.print(b[i][j] + "  ");
			}System.out.println();
		}

	
	}


}
