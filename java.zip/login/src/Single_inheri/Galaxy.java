package Single_inheri;

public class Galaxy {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Inheri_tance it  = new Inheri_tance();
		it.hello();
		
		Universe u = new Universe();
		u.hello1();
		u.moon();
		
		Galaxy g = new Galaxy();
		g.milkway();
		
		
	}

	public void milkway()
	{
		System.out.println("Milkway");
	}
}
