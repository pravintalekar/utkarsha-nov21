package Single_inheri;

public class Inheri_tance extends Universe {
	/*
	 *1) Single level - by using class
	 * 2)Multi level	- --''--
	 * 3)Multiple level  by Inteface
	 * 4) Hirachical Inheritance - 
	 * 
	 * 1) [parent class]
	 * 			|
	 * 		[Child class]
	 * one class to another class with extends keyword
	 * to extends multiple classes we use interfaces which is uesd in Multiple Inheritance
	 * syntax: child class extends Parent class
	 * 									|
	 * 								use its properties 
	 * 								for child class
	 * 
	 * 
	 * 2) [parent class]
	 * 			|
	 * 		  [c1]		
	 * 			|
	 * 		  [c2]
	 * 
	 * 3) [grand parent class]
	 * 			|
	 * 		[parent]
	 * 			|	\
	 * 		[child] [child]
	 * 
	 * using Interface
	 * 
	 * 
	 * only one single class can be extends
	 * only 3 objects can be created 
	 * 		|
	 * 1) child class object
	 * 2) parent class object
	 * 3) parent refer to child
	 */
	public static void main(String a[])
	{
		Inheri_tance it = new Inheri_tance();
		it.hello();
		it.hello1();     
		it.moon();     // static method
		
						/* static /non static method can be used . 
							if we use static method it shows only warning
	                   */
	}
public void hello()
{
System.out.println("Hello Universe");
}

}
class  Universe 
{
	public void hello1()
	{
		System.out.println("Hello Inheri_tance!!");
	}
	public static void moon()
	{
		System.out.println("hello I am moon");

	}
}


