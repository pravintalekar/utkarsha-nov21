
public class Addmethod {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
//int a=add(25);
//System.out.println(a);

Addmethod a1=new Addmethod();
//int o=a1.add(25);
//System.out.println(o);

int l=a1.div1(5,1);
System.out.println(l);
	}
	
	
	public static int add(int i)
	{
		int sum=0;
		for(int k=1; k<=i; k++) {
			sum=sum+k;
			System.out.println("sum= "+sum);
		}
		return sum;}
		
		public int div1(int i, int j)
		{
			int k=(i+j)/2;
			return k;
				
		}
	

}
