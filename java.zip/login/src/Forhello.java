
public class Forhello {
	public static void main(String a[]) {
		for(int i=0; i<10; i++)
			System.out.println("Hello World");
	}

}
