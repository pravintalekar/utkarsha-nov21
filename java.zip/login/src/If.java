
public class If {
	
	public static void main(String a[])
	{
	
	int math=60,
			hin=40,
		    eng=80, avg;
			
			avg=((math+hin+eng)/3);
			System.out.println(avg);
			
			if(avg>0 && avg<40) 
				System.out.println("Grade D"); 
			
			else if(avg>=40 && avg<60)
				
				System.out.println("Grade C");
				
			else if(avg>=60 && avg<80)
				
				System.out.println("Grade B");
			
			else if(avg>=80 && avg<100)
				
				System.out.println("Grade A");

}
}