package login;

public class Methods {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	hello( 1 , 1.1f, "this is static method. compile time binding.");	
	Methods m= new Methods();
	m.hello1("This is non static method. Run time binding");
	m.hello(1 , 1.1f, "this is static method. compile time binding."); //difference1
	
		
	int l =add(20, 10);
	System.out.println("static sum= "+l); //or
	System.out.println("static sum= "+ add(40,10));
	
	int n = m.add(80,80);
System.out.println("non-static sum= "+ n);//or
System.out.println("non-static sum"+  add(40,10));


System.out.println("static sum= "+ add1(4.0f,6.0f));
System.out.println("non-static sum"+add1(4.0f,1.0f));

	}
	
	public static void hello( int i, float f, String s) { // static
System.out.println("hiiii "+s +i +f);
	}
	
	public void hello1(String s1) { //non static
System.out.println("Hi "+s1);
}
	
	
	public static int add(int i,int j) {
		int k = i+j;
		return k;
		
	}
	public static float add1(float p,float q) {
		float r = p+q;
		return r;	
		
		}
	
	
}
