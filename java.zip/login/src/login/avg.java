package login;

public class avg {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//average of marks
		int mar=80,hin=96,eng=86,math=70,sci=60;
		int avg;
		
		avg=(mar+hin+eng+math+sci)/5;
		if(avg>40)
			System.out.println("You Passed");
		else
			System.out.println("You failed");

	}

}
