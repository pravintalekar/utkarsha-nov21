
public class For {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		/* for, while,dowhile 
		 * increment/decrement operator ++,--
		 * unary operator postfix expr++ , prefix ++expr 
		 * */
		
		int i,j=10;
		i=j++;                             // postfix increment operator
		System.out.println("i "+i);
		System.out.println("j "+j);
		
		int a,b=20;
		a=++b;							  // prefix increment operator
		System.out.println("a "+a);
		System.out.println("b "+ b);
		
		int x,y=40;
		x=--y;							  // prefix decrement operator
		System.out.println("x "+x);
		System.out.println("y "+ y);
		
		int p,q=30;
		p=q--;							  // prefix increment operator
		System.out.println("p "+p);
		System.out.println("q "+ q);
		
	}

}
