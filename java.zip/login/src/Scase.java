import java.util.Scanner;

public class Scase {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		/*
		 * switch case (int,byte,short,string,char)	
		 * scanner class is uesd to get input from user.
		 * SOP("enter a value");
		 * int i =sc.nextInt();
		 */
		
		 Scanner sc= new Scanner(System.in);
		 System.out.println("Enter a case value ");
			String s=sc.nextLine();
			
			
			switch(s) {
			case "Mon":System.out.println("Monday");
			break;
			
			case "Tue":System.out.println("Thusday");
			break;
			
			case "Wed":System.out.println("Wednsday");
			break;
			
			case "Thus":System.out.println("Thusrday");
			break;
			
			case "Fri":System.out.println("Friday");
			break;
			
			case "Sat":System.out.println("Saturday");
			break;
			
			case "Sun":System.out.println("Sunday");
			break;
			
			default: System.out.println("valid cases=== Mon or Tue or Wed or Thus or Fri or Sat or Sun ");
			
	}

}
}
