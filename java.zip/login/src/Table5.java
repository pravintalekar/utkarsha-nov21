
public class Table5 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		// (int ; break ; incmt/decmt)
		
		
		int table= 1;
for(int i=1; i<=10; i++) {
	//System.out.println(i*5);   //decrement 
	table=i*5;
System.out.println("5 table  "+table);}
	}

}
