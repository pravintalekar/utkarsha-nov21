
public class Wtable5 {
	
	public static void main(String a[])
	{
		/*int i=1;
		while(i<=10)
		{
			System.out.println(i*5);
			i++;
		}*/
		
		/*int j=10;
		while(j>=1)
		{
			System.out.println(j*5);
			j--;
		}*/
		
		int a1=1,sum=0;
		while(a1<=10)
		{
			sum=sum+a1;						//o/p sum 55
			a1++;
		}System.out.println(" sum "+sum);
	}

}
