
public class array1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int i[] = {2,3,5,88,55};
		
	/*	for(int j=0; j<=4; j++) {
		System.out.println(i[j]);
		}
	int l=i.length;
	System.out.println("Length of array= "+l);*/
	
	int tot=0;
	for(int k=i.length-1; k>=0; k--)
	{
		tot=tot+i[k];
	}		
	System.out.println("Total= "+tot); //sum of array elements
}

}
/*most used 1d array
 * at 2d arrays.
 * multid arrays are created in matrix form
 * a[][] 2d array   a[][][]3d array
 *  values are put in matrix form 
 *  {  {2,3}  {4,5} }
 *       |
 *  single array, 1st element [0]     				[1]
 *  							|					 |
 *  						{2,3}= 2=00, 3=01		 |
 *  											{4,5}= 4=10, 5=11
 *  int b[][]=new int[3][3];
 *  
 *  		col 0	col 1	col 2
 *  row 0   a[0][0]	a[0][1]	a[0][2]
 *  row 1	a[1][0]	a[1][1]	a[1][2]
 *  row 2	a[2][0]	a[2][1]	a[2][2]
 *  
 *  
 *  
 *  */
 