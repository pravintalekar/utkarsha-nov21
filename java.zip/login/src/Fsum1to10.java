
public class Fsum1to10 {
	public static void main(String a[]) {
		int i, sum=0;
		for( i=1; i<=10; i++) {
			sum=sum+i;
			System.out.println("sum= "+sum);
		
		}
		System.out.println(sum);
	}

}
