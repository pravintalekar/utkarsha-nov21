package multilevel_Inheri;

/*
 * allocation of properties
 * Grand_parent --to--->Parent ---to--> Child
 * 
 * 
 */

public class child extends parent {

	public void c1()
	{
		System.out.println("child class");
	}
}
