package multilevel_Inheri;

public class Grand_parent {
  public void GP()
  {
	  System.out.println("Grand parent class");
  }
}
