package multilevel_Inheri;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
Grand_parent gp = new Grand_parent();
gp.GP();

parent p = new parent();
p.GP();
p.p1();

child c = new child();
c.c1();
c.GP();
c.p1();


	}

}
