package multilevel_Inheri;

public class parent extends Grand_parent{

	
	public void p1()
	{
		System.out.println("parent class");
	}
}
