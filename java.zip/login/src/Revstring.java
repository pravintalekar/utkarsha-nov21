
public class Revstring {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
String s = "I AM NOT GOING TO SCHOOL";


char c[]= s.toCharArray();
System.out.println("---Reverse array String---");

	for (int i=c.length-1; i>=0; i--)
	{
		System.out.print(c[i]);
		
	}System.out.println();
	
	String st = "Reverse array string using charAt method";
	String rev = "";
	for(int j=st.length()-1; j>=0; j--)
	{
		rev=rev + st.charAt(j);
	}
	System.out.print(rev);
	}

}
/*
 * mostly asked in 
 * reverse sentence
 * by using array
 * first
 * convert into char array
 * char c[]= s.toCharArray();
 * char array reverse  in for loop
 * for(int i=c.length-1; i>=0 i--)
	 sop c[i]
 * 
 * what r the OOPs concepts
 * Data abstraction
 * Data Encapsulation
 * Inheritance - acquiring the property of parent class to the child class.
 * Polymorphism - 
 * 
 * 
 */
