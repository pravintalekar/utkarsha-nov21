package polymorphism;

public class Parent {
	
	
	public void add()
	{
		System.out.println("method overriding");
		System.out.println("Addition");
	}
	
}
