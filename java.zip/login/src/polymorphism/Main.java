package polymorphism;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Parent p = new Parent();
		p.add();
		
		Child c = new Child();
		c.add();
	}

}
