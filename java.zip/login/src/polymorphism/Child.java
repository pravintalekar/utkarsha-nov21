package polymorphism;

public class Child {

	public void add()
	{
		System.out.println("Addition of 2 integer");
	}
}
