package polymorphism;

public class Poly {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
/*
 * polymorphism - one entity has many forms
 *
 *can be achieved through ===
 *1)method overloading--> within single class
 *						>has to be same method name	
 *						>it uses both static and non- static method
 *						> compile time polymorphism
 *2)method overriding--- >within multiple classes (parent child relation)
 *						>has to be same method name
 *						>only non-static method used 
 *							i.e overriding of static method can not be done and also a final, private method
 *						>parent class method overrides in child class i.e output changes at run time.
 *						> it is a run time polymophism
 *
 *shaLLOW COPY and deep copy(run time polymorphism)
 *
 *compiler identifies method  through parameter/input , data types
 *
 *main method can be overload by some changes.
 *compiler compiles as general/simple method.
 *
 */
		add();
		add(5,10);
		add(5,5,5);
		add(2.1f,3.1f);
		
		main("Main method can be overload by some changes and it compiles as general method");
	}
	public static void main(String s) {
		System.out.println(s);
	}
	
	public static void add()
	{
		System.out.println("----Method overloading----");
	}
	public static void add(int i, int j)
	{
		int a=i+j;
		System.out.println("2 Integers Addn " + a);
	}
	public static void add(int i, int j, int k)
	{
		int b=i+j+k;
		System.out.println("3 Integers Addn " + b);
	}
	public static void add(float i, float j)
	{
		float c= i+j;
		System.out.println("float Addn " + c );
	}

}
