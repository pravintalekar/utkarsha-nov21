
public class salavg {
	
	public static void main(String a[]) {
		
	
	int sal,perday=1000, days=31, allow=15000;
	sal=((days*perday)+ allow);
	System.out.println(sal);
if(sal>50000)
{
	System.out.println("salary > than 50k");
}
	else
	{
		System.out.println("salary < than 50k");
	}

}
}