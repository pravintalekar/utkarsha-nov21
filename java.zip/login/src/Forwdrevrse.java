
public class Forwdrevrse {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
	/*	int a[]= {1,2,3,4,5,6};
		
		System.out.println("Forward Array Print");

		for(int i=0; i<=a.length-1; i++)
		{
		System.out.println(a[i]);						// type 1 intialization
		}
		System.out.println("Reverse Arrray Print");
		
		for(int j=a.length-1; j>=0; j--)
		{
			
		System.out.println(a[j]);
		}*/
		
		int a1[]=new int[5];
		a1[0]=21;
		a1[1]=22;
		a1[2]=23;
		a1[3]=24;
		a1[4]=25;
	/*	
		System.out.println("Forward Arrya Print");
		
		for(int m=0; m<=a1.length-1; m++)
		{
			System.out.println(a1[m]);
		}													//type 2 Intialization
		
		System.out.println("Backward Arrya Print");
		*/
		int tot=0;
		for(int n=a1.length-1; n>=0; n--)
		{
			tot=tot+a1[n];
			System.out.println("--> "+ tot);
		}
		System.out.println(tot);
	}

}
